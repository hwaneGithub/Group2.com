from django.contrib import admin
from players.models import Player

admin.site.register(Player)
