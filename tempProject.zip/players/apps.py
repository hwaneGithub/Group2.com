from django.apps import AppConfig


class PlayerConfig(AppConfig):
    name = 'players'
